    @extends('layouts.landinglayout')
    @section('css')
	
	 <link type="text/css" rel="stylesheet" href="{{ asset('css/shop.css') }}">
    @endsection
    @section('content')
       
            <!-- wrapper-->
            <div id="wrapper">
                <!-- content-->
                <div class="content">
                    <section class="gray-bg no-top-padding-sec" id="sec1">
                        <div class="container" style="margin-top: 30px;">
                          <div class="col-lg-11" style="float:none;margin:auto;">
                            <div class="fl-wrap">
                                <div class="row">
                                    <div class="col-md-8">
                                        <!-- list-single-main-item --> 
                                        <div class="user-profile-header fl-wrap">
                                            <div class="user-profile-header_media fl-wrap">
                                                <div class="bg"  data-bg="{{ asset('images/user_bg.jpg') }}"></div>
                                                <div class="user-profile-header_media_title">
                                                    <h3 style="font-size:30px;">{{ $user->firstname }} {{ $user->lastname }}</h3>
                                                    <h4> </h4>
                                                </div>
                                               
                                                
                                            </div>
                                            <div class="user-profile-header_content fl-wrap">
                                                 
											<div class="user-profile-header-avatar">
                                                    <img src="{{ asset( $user->image ) }}" alt="">
                                            </div>
											<div style="float: right;text-align: left;color: #878c9f; font-size: 14px;">
												 <h4 style="margin-bottom: 5px;">Location: {{ $user->location }}</h3>
                                                    <h4><span><i class="fas fa-map-marker-alt"></i>  Office Address:</span> {{ $user->address }}</h4>
                                             </div>   
                                                
                                                
                                            </div>
                                        </div>
										
										
										<div class="list-single-main-item fl-wrap block_box">
                                            <div class="list-single-main-item-title">
                                                <h3>About {{ $user->firstname }}</h3>
                                            </div>
                                            <div class="list-single-main-item_content fl-wrap">
                                                <p>{{ $user->about }}  </p>
                                            </div>
                                        </div>
                                        <!-- list-single-main-item end --> 
							
										
                                  
                                  
                                        <!-- listing-item-container end -->
                                    </div>
                                    <div class="col-md-4">
                                         <!--box-widget-item -->
                                        <div class="box-widget-item fl-wrap block_box">
                                            <div class="box-widget-item-header">
                                                <h3>Activity </h3>
                                            </div>
                                            <div class="box-widget">
                                                <div class="box-widget-author fl-wrap">
                                                    <div class="box-widget-author-title">
                                                        <div class="box-widget-author-title-img">
                                                            <img src="{{ asset( $user->image ) }}" alt=""> 
                                                        </div>
                                                        <div class="box-widget-author-title_content">
                                                            <a href="{{URL('/referred-realtors/'.$user->slug)}}">{{ $user->firstname }}
                                                            <span> Referred {{$refusers->count()}} Person(s)</span></a>
                                                        </div>
                                                        <div class="box-widget-author-title_opt">
                                                            <a href="#" class="tolt color-bg cwb" data-microtip-position="top" data-tooltip="Chat With {{ $user->name }}"><i class="fas fa-comments-alt"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--box-widget-item end -->                                  
                                                                      
                                          <!--box-widget-item -->                                       
                                        <div class="box-widget-item fl-wrap block_box">
                                            <div class="box-widget-item-header">
                                                <h3>Contact </h3>
                                            </div>
                                            <div class="box-widget">
												<div class="box-widget-content bwc-nopad">
                                                    <div class="list-author-widget-contacts list-item-widget-contacts bwc-padside">
                                                        <ul class="no-list-style">
                                                            <li><span><i class="fal fa-phone"></i> Mobile :</span> <a href="#">{{ $user->mobile }}</a></li>
                                                            <li><span><i class="fab fa-whatsapp"></i> Whatsapp :</span> <a href="#">{{ $user->whatsapp }}</a></li>
                                                            <li><span><i class="far fa-envelope"></i> Email :</span> <a href="#">{{ $user->email }}</a></li>
                                                            <li><span><i class="fas fa-map-marker-alt"></i> Address :</span> <a href="#">{{ $user->address }}</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="list-widget-social bottom-bcw-box  fl-wrap">
                                                        <ul class="no-list-style">
                                                            <li><a href="https://facebook.com/{{ $user->facebook }}" target="_blank" ><i class="fab fa-facebook-f"></i></a></li>
                                                            <li><a href="https://twitter.com/{{ $user->twitter }}" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                                            <li><a href="https://linkedin.com/{{ $user->linkedin }}" target="_blank" ><i class="fab fa-linkedin"></i></a></li>
                                                            <li><a href="https://instagram.com/{{ $user->instagram }}" target="_blank" ><i class="fab fa-instagram"></i></a></li>
                                                        </ul>
                                                      
                                                    </div>
													
                                                </div>
                                            </div>
                                        </div>
                                        <!--box-widget-item end -->                           
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </section>
                </div>
                <!--content end-->
				
				
				
				
				
				
				
            </div>
    @endsection
	
	@section('script')
	
	
	 @endsection
	
   
   